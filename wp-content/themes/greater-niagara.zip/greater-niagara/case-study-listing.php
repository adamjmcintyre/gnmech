<?php
/**
 * Case study template.
 *
 * @package WordPress
 * @subpackage IsoBlog
 */
/*
 * Template Name: Case Study Listing
 */
?>

<?php get_header(); ?>
<?php write_case_studies(); ?>
    
<?php get_footer(); ?>
