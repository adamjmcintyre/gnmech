<?php get_header(); ?>
	<div id="content" class="narrowcolumn">
		<h2 class="center">Unavailable!</h2>
		<div class="404">
			<p>The URL you have tried to access is unavailable.</p>
			<p>
				Please try again.
			</p>
		</div>
	</div>
<?php get_footer(); ?>
