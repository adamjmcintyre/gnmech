<?php
       require "/big/dom/xdrunkenfist/www/_assets/inc/quickcache/quickcache.php";
       echo time();
       phpinfo();
       ?>